#!/usr/ptyhon


import sys, os, time
import socket
import fcntl
import struct


def printHello():
    print ("HELLO")

print (time.time())
print (time.clock())
