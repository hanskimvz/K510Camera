﻿
$(function () {
	$("div#browserChecked").append("<ul><li>Your web browser does not support.</li><li>Please try one of these more modern browsers.</li><li id='browser'><span>IE8.0 or later</span><span>Firefox</span><span>Chrome</span><span>Safari</span></li></ul>");
	$("div#browserChecked").css('display', 'block');
});