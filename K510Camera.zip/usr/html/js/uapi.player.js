//var player_version = "1,0,9,1";
var player_version = "2,1,4,14167";
var PLAYER_UST = "89a88678-05e0-11e2";
var PLAYER_PST = "8b36ea84-05e0-11e2";
