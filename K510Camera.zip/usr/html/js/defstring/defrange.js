var g_defrange = {
	minbitrate : 128,
	maxbitrate : 12000,
	maxBitrateCBR : 8000
}