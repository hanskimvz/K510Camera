var g_defbrand = {
	ptz : "ptz",
	type1ptz : "speed type 1",
	irptz : "ir speed ptz",
	existrepositioning : "1",
	existautorun : "1",
	existtouring : "1",
	existswtouring : "2",
	di2dn : "di2dn",
	dmva2 : "dmva2",
	thermal1 : "thermal1"
}

//day & night transition whitelist
var g_defdnt = {
	dntAllowModel : ["ov2715", "ov9715", "imx122", "ar0330", "mt9p031", "imx222", "imx322", "en773v"],
}