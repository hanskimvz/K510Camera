var g_defconfig= {
	rebootWaitSeconds : 135
}