var g_defpath = {
	param : "/nvc-cgi/admin/param.cgi",
	paramuapi : "/uapi-cgi/admin/param.cgi",
	paramuapijs : "/uapi-cgi/admin/paramjs.cgi",
	adrdownload : "/nvc-cgi/admin/adrdownload.cgi",
	timezone : "/nvc-cgi/admin/timezone.cgi"
}